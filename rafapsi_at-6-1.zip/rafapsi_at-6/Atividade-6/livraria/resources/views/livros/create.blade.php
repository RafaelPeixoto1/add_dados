<form action="{{route('livros.store')}}" method="post">
@csrf
Titulo: <input type="text" name="titulo"><br><br>
Idioma: <input type="text" name="idioma"><br><br>
Total paginas: <input type="text" name="total_paginas"><br><br>
Data Edição: <input type="text" name="data_edicao"><br><br>
ISBN: <input type="text" name="isbn" value="{{old('isbn')}}"><br><br>
@if ($errors->has('isbn'))<br><br>
Devera indicar um ISBN correto (13 carateres)
@endif
Observações: <textarea  name="observacoes"></textarea><br><br>
Imagem capa: <input type="text" name="imagem_capa"><br><br>
Genero:<input type="text" name="id_genero"><br><br>
Autor:<input type="text" name="id_autor"><br><br>
Sinopse:<textarea name="sinopse">{{old('sinopse')}}</textarea><br><br>
<input type="submit" value="Enviar">
</form>