ID:{{$edicoes->id_liro}}<br>
Nome:{{$editora->nome}}<br>
Nacionalidade:{{$editora->morada}}