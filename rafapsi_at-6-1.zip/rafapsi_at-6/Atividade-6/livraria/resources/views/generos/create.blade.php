<form action="{{route('generos.store')}}" method="post">
@csrf
Designacao: <input type="text" name="designacao"><br><br>
Observacoes: <input type="text" name="observacoes"><br><br>

<input type="submit" value="Enviar">
</form>