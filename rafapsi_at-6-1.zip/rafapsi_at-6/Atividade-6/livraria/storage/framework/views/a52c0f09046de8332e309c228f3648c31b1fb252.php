ID:<?php echo e($livro->id_livro); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?>


<?php if(isset($livro->genero->designacao)): ?>
<?php echo e($livro->genero->designacao); ?>

<?php endif; ?><?php /**PATH D:\PSI\Atividade-4\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>